package Assessments;

public class pgm2 {

	public static void main(String[] args) {
		String line="Hello i am working at Global Logic";
		extract_word(line);
		
	}
	public static String[] extract_word(String str)
	{
		String str1;
		int p=0;
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==' '&&str.charAt(i+1)!=' ')
			{
				str1=str.substring(p,i);
				p=i+1;
				count_print(str1);
			}
		}
		return null;
		
	}
	public static String[] count_print(String words)
	{
		if(words.length()>5)
		{
			System.out.println(words);
		}
		
		return null;
	}
}
