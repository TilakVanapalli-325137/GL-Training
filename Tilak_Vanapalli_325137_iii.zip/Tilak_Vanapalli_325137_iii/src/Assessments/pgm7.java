package Assessments;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parrots p1 = new parrots(49,4500,70,"Red","fruits and seeds","male","nanuu",2);
		parrots p2 = new parrots(52,5000,60,"Green ","fruits","female","jumase",2);
		parrots p3 = new parrots(18,112,10,"reddish green","insects","female","tluyy",2);
		owls o1 = new owls(30,660,5,"White","flies","male","hureey",2);
		owls o2= new owls(40,1500,3,"Black","insects","female","Sissy",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.imitate();
		p2.flys();
		p3.display();
		p3.eats();
		p3.screams();
		
		o1.display();
		o1.eats();
		o1.rotatesneck();
		o2.display();
		o2.hunts();
		
		

	}

}
