package DAY6;

public class Elephant extends Animal{
		int lot;
		int lotusks;
		int legs;
		int age;
		String gender;
		String disabilities;
		public void swim() {
			System.out.println("Elephant swims");
		}
		

		public void spraying() {
			System.out.println("Elephant sprays using trunks");
		}
		public void acts() {
			System.out.println("This Elephant acts");
		}
		
			
		public Elephant(int lot, int lotusks,int legs,int age,String gender,String disabilities) {
			this.lot=lot;
			this.lotusks=lotusks;
			this.legs=legs;
			this.age=age;
			this.gender=gender;
			this.disabilities=disabilities;
		}


		public void display() {
			System.out.println(" Name: "+this.name +" No of legs: " +this.legs + " Skin color: "+ this.color + " Food: " + this.food 
								+ " Gender: " + this.gender + " Age: " + this.age+"Disabilities :"+this.disabilities );
			
			System.out.println(" Length of trunk : "+ this.lot +" meters "+" Length of tusks: " + this.lotusks);
		}
}
