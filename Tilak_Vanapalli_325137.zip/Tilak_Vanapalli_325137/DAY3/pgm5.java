package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		int marks[][]= {{75,65,56,18},{34,14,11,89},{76,66,45,32}};
		int row[]=new int[4];
		
		
		for(int i=0;i<=2;i++)
		{
			for(int j=0;j<=3;j++)
			{
				System.out.print(marks[i][j]+" ");
			}
			System.out.println(" ");
		}

		for(int l=0;l<=2;l++)
		{
			for(int m=0;m<=3;m++)
			{
				row[m]=marks[l][m];
			}
		maxofrow(row);
		}
		
	}

	public static void maxofrow(int row[])
	{
		int res[]=new int[4];
		for(int n=0;n<=3;n++)
		{
			res[n]=	row[n];
		}	
			int max;
			max=res[0];


		for( int l=0;l<=3;l++)
		{
			for(int p=l+1;p<=3;p++)
			{
				if(res[p]>res[l])
				{
					max=res[p];
				}
				
			}

			
		}
		System.out.println("large element of each row is :"+max);
			
	}
}
