package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		int num[]= {21,34,91,59,16,44,29,36,49,31};
	
			for(int i=0;i<num.length;i++)
			{
				for(int j=i+1;j<num.length;j++)
				{
				if(num[i]+num[j]==65)
				{
					System.out.println("sum of "+num[i]+" and "+num[j]+" is 65");
				}
				}
			}
	
	}
}
