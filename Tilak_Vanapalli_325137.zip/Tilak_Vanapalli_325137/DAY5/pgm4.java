package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm4 {

	public static void main(String[] args) {
		try {
			File f=new File("C:\\Training\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("sheet1");
			XSSFRow r1=sh.getRow(0);
			XSSFCell c1=r1.getCell(0);
			XSSFRow r=sh.createRow(3);
			XSSFCell c=r.createCell(0);
			String s=c1.getStringCellValue();
			System.out.println(s);
			
			c.setCellValue("Selenium");
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

}
