package DAY2;

public class pgm11 {

	public static void main(String[] args) {
		int i,j,t=1,p=400,n=1,sum=0;
		boolean k;
		System.out.println(" primes are :");
		while(n<=10)
		{
		 k=isprime(t);
		 if(k==true)
		 {
			 System.out.print(t+" ");
			 sum=sum+t;
			n++;
		 }
		 t++;
		}
		System.out.println("The sum of first 10 primes is : "+sum);

	}

	public static boolean isprime(int p)
	{
		int l,m,count=0;
		m=p;
		for(l=1;l<=m;l++)
		{
			if(p%l==0)
			{
				count++;
			}
		}
		if(count==2)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}
