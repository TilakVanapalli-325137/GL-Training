package DAY2;

import java.util.Scanner;

public class pgm1 {

	public static void main(String[] args) {

		int i;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		i=sc.nextInt();
		switch(i)
		{
		case 0:
			System.out.println("zero");
			break;
		case 1:
			System.out.println("one");
			break;
		case 2:
			System.out.println("two");
			break;
		case 3:
			System.out.println("three");
			break;
		case 4:
			System.out.println("two");
			break;
		case 5:
			System.out.println("five");
			break;
		case 6:
			System.out.println("Six");
			break;
		case 7:
			System.out.println("Seven");
			break;
		case 8:
			System.out.println("eight");
			break;
		case 9:
			System.out.println("Nine");
			break;
		default:
			System.out.println("out of switch");
		}
		
	}

}
