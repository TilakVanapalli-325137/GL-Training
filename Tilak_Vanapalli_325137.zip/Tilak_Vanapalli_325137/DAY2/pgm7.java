package DAY2;
import java.util.Scanner;
public class pgm7 {

	public static void main(String[] args) {
		int i,sum=0,t=0;
		System.out.println("enter a number");
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		while(i!=0)
		{
			t=i%10;
			i=i/10;
			if(t>5)
			{
			sum=sum+t;
			}
			
			
		}
		System.out.println(sum);

	}

}
