package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		int i,j;
		for(i=5,j=4;i<=9;j=j+2,i++)
		{
			if(j<=12)
				System.out.println(i+"*"+j+"="+(i*j));
		
		}

	}

}
