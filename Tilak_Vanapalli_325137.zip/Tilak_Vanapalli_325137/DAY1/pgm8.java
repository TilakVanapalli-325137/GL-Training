package DAY1;

public class pgm8 {

	public static void main(String[] args) {
		int e=10;
		  int f=20;
		  e+=4;
		  f-=4;
		  System.out.println(e);
		  System.out.println(f);
	}

}
