package DAY1;

public class pgm2 {

	public static void main(String[] args) {
		int a,n=12321,b=0,c=0,i,d=0,e=0;
		d=n;
		e=n;
		while(d!=0)
		{
			d=d/10;
			c++;
		}
		a=n;
		for(i=0;i<c;i++)
		{
			a=n%10;
			b=b*10+a;
			n=n/10;
		}
		System.out.println(b);
		
		if(e==b)
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not a Palindrome");
		}
	}

}
