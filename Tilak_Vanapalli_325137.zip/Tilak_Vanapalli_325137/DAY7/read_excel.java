package DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;

public class read_excel {


	public ArrayList<student> read_excell()
	{
		
		ArrayList<student> std_al=new ArrayList<student>();
		try {
			File f=new File("C:\\Training\\Book2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			
			for(int i=1;i<=8;i++)
			{
				student s=new student();
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			s.rollno=(int) c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			s.name= c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			s.sub1=(int) c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			s.sub2=(int) c3.getNumericCellValue();
			s.average();
			std_al.add(s);
			
			}
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return std_al;
	}
	public void write_excel(ArrayList<student> al_std1)
	{
		int row=1;
		try {
		File f=new File("C:\\Training\\Book2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet1");
		
		
		for(student s1 : al_std1)
		{
		XSSFRow r=sh.getRow(row);
		XSSFCell c=r.createCell(4);
		c.setCellValue((double) s1.avg);
		row++;
		}
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
}
