package DAY7;

import java.util.ArrayList;

import DAY3.student;

public class excel {

	public static void main(String[] args) {
		read_excel ex=new read_excel();
		ArrayList<student> std_alist=new ArrayList<student>();
		std_alist=ex.read_excell();
		ex.write_excel(std_alist);
		
	}

}
