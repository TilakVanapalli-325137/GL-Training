package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		int num[]= {21,34,91,59,16,25,29,74,49,82};
		int sum=0;
		boolean k;
		for(int i=0;i<num.length;i++)
		{
			k=evencheck(num[i]);
			if(k==true)
			{
				sum=sum+num[i];
			}
			
		}
		System.out.println(sum);
	}
public static boolean evencheck(int y)
{
	
if(y%2==0)
{
	return true;
}
	
else {
	
	return false;
	}
}	
	
}
