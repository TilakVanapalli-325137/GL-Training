package DAY3;

public class college {

	public static void main(String[] args) {
		student rakesh=new student();
		 rakesh.rollno=501;
		 rakesh.name="rakesh";
		 rakesh.m1=78;
		 rakesh.m2=99;
		 rakesh.average();
		 System.out.println(rakesh.rollno);
		 System.out.println(rakesh.name);
		 System.out.println(rakesh.m1);
		 System.out.println(rakesh.m2);
		 System.out.println(rakesh.avg);
		 student priya=new student();
		 priya.rollno=502;
		 priya.name="Priya";
		 priya.m1=68;
		 priya.m2=88;
		 priya.average();
		 System.out.println(priya.rollno);
		 System.out.println(priya.name);
		 System.out.println(priya.m1);
		 System.out.println(priya.m2);
		 System.out.println(priya.avg);
	}

}
