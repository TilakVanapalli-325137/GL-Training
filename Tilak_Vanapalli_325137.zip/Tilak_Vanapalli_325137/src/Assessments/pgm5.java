package Assessments;

public class pgm5 {

	public static void main(String[] args) {
		int arr[]= {23,44,84,37,91,18};
		int sum=0;
		for(int i=0;i<6;i++)
		{
			if(i%2==0)
			{
				if((arr[i]%2)!=0)
				{
					sum=sum+arr[i];
				}
			}
		}
		System.out.println(sum);

	}

}
