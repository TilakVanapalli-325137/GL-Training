package Assessments;

import java.util.ArrayList;

public class pgm4 {

	public static void main(String[] args) {
		int j,i,n,sum,count=0;
		ArrayList<Integer> i_al=new ArrayList<Integer>();
		for(j=1;j<=10000;j++)
		{
		sum=0;
		n=j;
		while(n!=0)
		{
			i=n%10;
			sum=sum+(i*i*i);
			n=n/10;
		}
		if(j==sum)
		{
			i_al.add(sum);
			count++;
		}
		if(count==5)
		{
			System.out.println(i_al);
			break;
		}
		}
		
	}

}
