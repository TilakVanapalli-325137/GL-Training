package Assessments;

public class pgm1 {

	public static void main(String[] args) {
		int a1[]=new int[30];
		int a2[]=new int[30];
		int c=0,t=0;
		for(int i=10;i<=30;i++)
		{
			if(i%3==0)
			{
				a1[c]=i;
				c++;
			}
			if(i%5==0)
			{
				a2[t]=i;
				t++;
			}
		}
		for(int j=0;j<=c;j++)
			
		{
			for(int k=0;k<=t;k++)
			{
			if(30<(a1[j]+a2[k])&&(a1[j]+a2[k])<40)
			{
				System.out.println(a1[j]+" + "+a2[k]+" = "+(a1[j]+a2[k]));
			}
			}
		}

	}

}
