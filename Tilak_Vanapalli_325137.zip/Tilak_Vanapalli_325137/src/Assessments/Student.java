package Assessments;

public class Student {
int rollno;
String name;
int java;
int selenium;
float avg;
public Student(int rollno,String name,int java,int selenium)
{
	this.rollno=rollno;
	this.name=name;
	this.java=java;
	this.selenium=selenium;
	
}

	public float average()
	{
		this.avg=(float)(this.java+this.selenium)/2;
		return avg;
	}

	public void Display()
	{
		if(this.avg>=65)
		{
			System.out.println("Roll num is : "+this.rollno+"  Name is :"+this.name+"   Java Marks is :"+this.java+"  Selenium Maerks is :"+this.selenium+"   Average Is :"+this.avg);
		}
		
	}


}
