package Assessments;

public class cal_avg {

	public static void main(String[] args) {
		Student s1=new Student(101,"Rakesh ",68,88);
		Student s2=new Student(102,"Priya",78,85);
		Student s3=new Student(103,"Tilak",55,50);
		s1.average();
		s2.average();
		s3.average();
		s1.Display();
		s2.Display();
		s3.Display();
	}

}
