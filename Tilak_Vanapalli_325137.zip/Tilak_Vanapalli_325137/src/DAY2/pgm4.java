package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		int i,sum=0;
		for(i=10;i<=50;i++)
		{
			if(i%5==0)
			{
				if(i==50)
				{
					System.out.print(i);
				}
				else
				{
				System.out.print(i+"+");
				}
				sum=sum+i;
			}
		}
		System.out.print("="+sum);

	}

}
