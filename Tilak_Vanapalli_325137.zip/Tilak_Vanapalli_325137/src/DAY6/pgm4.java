package DAY6;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant e1 = new Elephant(1,6,4,28,"male","NOT PH");
		Elephant e2 = new Elephant(1,5,4,33,"female","NOT PH");
		Tiger t1 = new Tiger(6,7,4,24,"male","NOT PH");
		Tiger t2 = new Tiger(7,9,3,20,"female","YES PH");
		
		e1.color="Black";
		e1.food="Tree bark";
		e1.name=" Ayiravatham";
		e1.display();
		e1.eats();
		e1.swim();
		
		
	
		e2.color="Black";
		e2.food="twigs";
		e2.name="Black ayiravatham";
		e2.display();
		e2.eats();
		e2.swim();
		e2.runs();
		e2.acts();
		

		t1.color="Red-Orange";
		t1.food="Deers";
		t1.name="baban Share";
		t1.climb();
		t1.eats();
		t1.mauls();
		t1.roar();
		t1.display();
		
		t2.color="White";
		t2.food="Fishes";
		t2.name="faltoos";
		t2.climb();
		t2.eats();
		t2.mauls();
		t2.roar();
		t2.runs();
		t2.display();

	}

}
