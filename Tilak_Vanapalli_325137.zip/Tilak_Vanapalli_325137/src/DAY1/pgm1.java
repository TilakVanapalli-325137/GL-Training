package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		int i,j,n=100,sum=0,t=0;
		for(i=1;i<n;i++)
		{
			int count=0;
			for(j=1;j<n;j++)
			{
				
				if(i%j==0)
				{
					count++;
				}
			}
			
			if(count==2)
			
			{
				
				sum=sum+i;
				t++;
				System.out.println(i+"is the "+t+"th Prime");
			}
			if(t==10)
			{
				System.out.println(sum+" is the Sum");
				break;
			}
		}
	}

}
