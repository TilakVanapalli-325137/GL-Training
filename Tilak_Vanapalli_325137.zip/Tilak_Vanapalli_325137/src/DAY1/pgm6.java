package DAY1;

public class pgm6 {

	public static void main(String[] args) {
		int d=10;
		int c=5;
		System.out.println(d+c);
		System.out.println(d-c);
		System.out.println(d*c);
		System.out.println(d/c);
		System.out.println(d%c);
		
		
	}

}
