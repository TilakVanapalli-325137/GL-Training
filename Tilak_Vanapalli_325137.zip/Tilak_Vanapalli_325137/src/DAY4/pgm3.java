package DAY4;
public class pgm3 {

	public static void main(String[] args) {
		String s1="I am working with Global Logic in Noida ";
		String s2;
		int p=0,c=0,t=0;
		int a[]=new int[50];
		while(p!=-1)
		{
			p=s1.indexOf(" ",p+1);
			if(p!=-1)
			{
			c++;
			}
			a[c+1]=p;
		}
		
		System.out.println(" no of spaces are "+c);
		t=c;
		for(int i=0;i<=c;i++)
		{
			if(i!=t)
			{
			s2=s1.substring(a[i],a[i+1]);
			System.out.println(s2=s2.trim());
			}
		}
	}

}

