package DAY4;

public class pgm1 {

	public static void main(String[] args) {
		int cmax=4;
		int dmax=1;
		for( int r=1;r<=3;r++)
		{
			
			for(int c=1;c<=cmax;c++)
			{
				System.out.print(" ");
				
			}
			
			for(int d=1;d<=dmax;d++)
			{
				System.out.print("1"+" ");
			}
			
			cmax=cmax-2;
			dmax=dmax+1;
			System.out.println();
		}

	}

}
