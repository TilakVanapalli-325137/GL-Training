package DAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.student;

public class read_excel {


	public student read_excell(int n)
	{
		student s=new student();
		try {
			File f=new File("C:\\Training\\Book2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh= wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(n);
			XSSFCell c=r.getCell(0);
			s.rollno=(int) c.getNumericCellValue();
			
			XSSFCell c1=r.getCell(1);
			s.name= c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			s.sub1=(int) c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			s.sub2=(int) c3.getNumericCellValue();
			
			
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return s;
	}
	public void write_excel(int n,student s)
	{
		try {
		File f=new File("C:\\Training\\Book2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh= wb.getSheet("Sheet1");
		XSSFRow r=sh.getRow(n);
		XSSFCell c=r.createCell(4);
		c.setCellValue((double) s.avg);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}

	}
}
