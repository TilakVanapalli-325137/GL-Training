package DAY5;

public class pgm1 {

	public static void main(String[] args) {
		int n=10,m=0,p;
		p=n/m;
		System.out.println(p);
		

	}

}
