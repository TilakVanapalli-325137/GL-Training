package DAY5;

public class pgm3 {

	public static void main(String[] args) {
		try {
			int num[]= {1,2,3};
			int b=num[3];
			System.out.println(b);
		   
			
			int a=10, b1=0,c;
			c=a/b1;
			System.out.println(c);
			}
		catch(ArithmeticException e){
			System.out.println(" In Arithmetic exception catch blk");
			
			  }
		catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println(" Array OUT of Bounds exception catch blk");
		}
	}

}
