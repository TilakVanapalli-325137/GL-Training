package PCK_1;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  System.out.println("Maven classes");
  }
}
