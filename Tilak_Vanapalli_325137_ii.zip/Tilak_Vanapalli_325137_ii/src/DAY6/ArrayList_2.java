package DAY6;

import java.util.ArrayList;


public class ArrayList_2 {
	ArrayList<Student> std_al=new ArrayList<Student>();
	public void create_al()
	{
		Student s1=new Student("Ramesh",101,80,90);
		Student s2=new Student("Priya",102,85,95);
		std_al.add(s1);
		std_al.add(s2);
		}
	public void display()
	{
		for (Student s: std_al)
		{
			s.sub1=99;
			s.average();
			System.out.println("Name :"+s.name+"\n"
								+"Rollno :"+s.rollno+"\n"
								+"sel Marks :"+s.sub1+"\n"
								+"Java Marks :"+s.sub2+"\n"
								+"average :"+s.avg+"\n");
		}
	}

	public static void main(String[] args) {
		ArrayList_2 al=new ArrayList_2();
		al.create_al();
		al.display();

	}

}
