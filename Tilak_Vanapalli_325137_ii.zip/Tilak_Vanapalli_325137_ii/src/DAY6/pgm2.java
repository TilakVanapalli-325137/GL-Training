package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str=new ArrayList<String>();
		
		str.add("asf");
		str.add("Rakesh");
		str.add("Himanshu");
		str.add(" Suresh");
		
		System.out.println(" Before Insertion :"+str);
		str.add(2,"Tilak");
		System.out.println(" After Insertion :"+str);
		str.remove("Tilak");
		System.out.println("After deletion :"+str);
		str.remove(3);
		System.out.println(" After Another deletion :"+str);
		
	}

}
