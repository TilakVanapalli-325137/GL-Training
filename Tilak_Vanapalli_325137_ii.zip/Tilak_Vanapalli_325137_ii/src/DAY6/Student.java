package DAY6;


	public class Student {
		public int rollno;
		public String name;
		public int sub1;
		public int sub2;
		public float avg;
		
		public void average()
		{
			this.avg=(float)(this.sub1+this.sub2)/2;

		}
		public Student(String name,int rollno,int sub1,int sub2)
		{
			this.name=name;
			this.rollno=rollno;
			this.sub1=sub1;
			this.sub2=sub2;
		}

	}

