package DAY4;

public class calc_v1 {

	public int add(int x,int y)
	{
		int z=x+y;
		return z;
	}
	public float add(float x,float y)
	{
		return 1.0f;
	}
	public int add(float x,int y)
	{
		return 1;
	}
	public float add(int x,int z,float y )
	{
		return 2*z;
	}
	
}
