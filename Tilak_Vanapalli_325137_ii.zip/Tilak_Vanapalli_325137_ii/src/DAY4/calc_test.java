package DAY4;

public class calc_test {

	public static void main(String[] args) {
		calc_v1 calc=new calc_v1();
		int sum=calc.add(5, 10);
		System.out.println("first sum ="+sum);
		float s= calc.add(2,3,4.1f);
		System.out.println("Second sum ="+s);
	}

}
