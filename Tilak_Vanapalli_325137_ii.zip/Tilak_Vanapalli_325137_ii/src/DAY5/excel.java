package DAY5;

import DAY3.student;

public class excel {

	public static void main(String[] args) {
		read_excel ex=new read_excel();
		for(int i=1;i<=8;i++)
		{
		student s1=ex.read_excell(i);
		s1.average();
		ex.write_excel(i,s1);
		}
	}

}
