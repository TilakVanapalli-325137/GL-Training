package DAY2;

public class pgm5 {

	public static void main(String[] args) {
		int i,j;
		/* first shape */
		for(i=1;i<=5;i++)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			for(j=5;j>=i;j--)
			{
				
				
				System.out.print(i);
			}
			System.out.println(" ");
		}

		
		/* second shape*/
		for(i=5;i>=1;i--)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			
			for(j=5;j>=i;j--)
			{
				
				System.out.print(i);
			}
			
			System.out.println(" ");
		}
		/* third shape*/
		for(i=5;i>=1;i--)
		{
			
			for(j=1;j<=i;j++)
			{
				
				System.out.print(" "+j);
			}
			
			System.out.println(" ");
		}
		/* fourth shape */
		for(i=1;i<=5;i++)
		{
			
			for(j=1;j<=i;j++)
			{
				
				System.out.print(" "+j);
			}
			
			System.out.println(" ");
		}
		
		for(i=5;i>=1;i--)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			
			for(j=5;j>=i;j--)
			{
				
				System.out.print("1"+" ");
			}
			
			System.out.println(" ");
		}
		for(i=1;i<=5;i++)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			for(j=5;j>=i;j--)
			{
				
				
				System.out.print("1"+" ");
			}
			System.out.println(" ");
		}
		
	}

}
