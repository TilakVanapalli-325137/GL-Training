package DAY1;

import java.util.Scanner;
public class pgm12 {

	public static void main(String[] args) {
	
		int a;
		int b;
		int c;
		double avg;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter sub1 marks");
		a=sc.nextInt();
		System.out.println("enter sub2 marks");
		b=sc.nextInt();
		System.out.println("enter sub3 marks");
		c=sc.nextInt();
		if(a>0&&b>0&&c>0) {
		avg=(double)(a+b+c)/3;
		System.out.println(avg);
		if(avg>=60) {
			System.out.println("first class");
		}
			else if(50<=avg&& avg<60) {
			System.out.println("second class");
			}
			else if(35<=avg&&avg<50) {
			System.out.println("pass class");
			}
		else if(avg>=0&&avg<35) {
			System.out.println("fail");
		}
		else {
			System.out.println("enter valid marks");
		}

	}
		else
		{
			System.out.println("enter valid marks out of hundred");
		}
	}

}
