package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.Tdata;

public class pgm4 {
	pgm5 p=new pgm5();
	Tdata t,t1;
  @Test
  public void test1() {
	  t=new Tdata();
	  t1=new Tdata();
	  t.uid="tilaksthunder.111@gmail.com";
	  t.password="tilak0128"
	  		+ "";
	  t.exp_res="success";
	t1= p.login(t);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
  @Test
  public void test2() {
	  t=new Tdata();
	  t1=new Tdata();
	  t.uid="tilaksthunder.111@gmail.com";
	  t.password="tilak0112";
	  t.exp_res="success";
	t1= p.login(t);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
}
