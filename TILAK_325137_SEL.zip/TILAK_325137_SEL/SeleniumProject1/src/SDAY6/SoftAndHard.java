package SDAY6;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAndHard {
  @Test
  public void f() {
	  String ar="noida";
	  String er="noida";
	  
	  
	  SoftAssert sa=new SoftAssert();
	  AssertJUnit.assertEquals(er, ar);
	  
	  
	  System.out.println("Total 2 fails");
	  sa.assertAll();
  }
  @Test
  public void f1() 
  {
	  String ar1="noida1";
	  String er1="noida";
	  SoftAssert sa=new SoftAssert();
	  AssertJUnit.assertEquals(er1,ar1);
	  sa.assertAll();
	  
  }
  @Test 
  public void f2()
  {
	  String er2="Noida";
	  String ar2="Noida2";
	 
	  AssertJUnit.assertEquals(er2,ar2);
	 
  }
}
