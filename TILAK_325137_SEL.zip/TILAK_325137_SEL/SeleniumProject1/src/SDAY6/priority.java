package SDAY6;

import org.testng.annotations.Test;

public class priority {
  @Test(priority = 2)
  public void a() {

  System.out.println("Vanapalli");
  }
  @Test(priority = 0)
  public void b()
  {
	 System.out.print("Thirumala"); 
  }
  @Test(priority = 1)
  public void c()
  {
	  System.out.print("Tilak");
  }
}
