package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class feedback {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		//dr.get("https://globallogic.okta.com/login/login.htm?fromURI=%2Fapp%2Fgoogle%2Fexkco2xemQzomqLzc356%2Fsso%2Fsaml%3FSAMLRequest%3DfVLLTsMwELwj8Q%252BW70maIiSwmqACQlTiEbWBAzfH2Tgujh28Tgt%252Fj5uCgAO9jmfnsd7ZxXunyQYcKmsymsYTSsAIWysjM%252FpU3kRn9CI%252FPpoh73TP5oNvzRLeBkBPwqRBNj5kdHCGWY4KmeEdIPOCreb3d2waT1jvrLfCakoW1xmtpZQVb9q1adevYNdNI9tG66pqQfZQi8b0bV%252BJjpLn71jTXawF4gALg54bH6BJeh6laZSelJNzNj1l6fSFkuLL6VKZfYNDsao9CdltWRZR8bgqR4GNqsE9BHZGpbVSQyxst7MvOKLaBLjhGoGSOSI4HwJeWYNDB24FbqMEPC3vMtp63yNLku12G%252F%252FIJDyR2lZcayuV2CMCaT6ul40N3a%252B9Hs7Pv%252F1pfshhlvwSz78%252BctdvcV1YrcQHmQfy9soB96Gcd0PodmNdx%252F3%252F%252Fmmcjoiqo2akssFgD0I1CmpKknzv%252Bvdiwh19Ag%253D%253D%26RelayState%3Dhttps%253A%252F%252Faccounts.google.com%252FCheckCookie%253Fcontinue%253Dhttps%25253A%25252F%25252Fdocs.google.com%25252Fforms%25252Fu%25252F1%25252Fd%25252Fe%25252F1FAIpQLSeX-VJmGYVl7z4XHoqiNL0ED1tJyw6uF9P2d6yNJajJol6fOA%25252FformResponse%2526service%253Dwise%2526hl%253Den-GB%2526checkedDomains%253Dyoutube%2526checkConnection%253Dyoutube%25253A367%25253A1%2526pstMsg%253D1");
		//dr.get("https://globallogic.okta.com/login/login.htm?fromURI=%2Fapp%2Fgoogle%2Fexkco2xemQzomqLzc356%2Fsso%2Fsaml%3FSAMLRequest%3DfVJNT%252BMwEL2vxH%252BwfE9SA0Ks1QQVENpKsEQ0cODmOpPE4HiyHqdd%252Fv26KWjhQK%252FPb97HeOYXf3vLNuDJoMu5SGecgdNYG9fm%252FLG6Sc75RXH0Y06qt4NcjKFzD%252FBnBAosTjqS00POR%252B8kKjIkneqBZNBytbi7lcfpTA4eA2q0nC2vc46dg%252FrVvGiluw4GxB7bxtVtXzd2DQp0xGo1NJw9fcQ63sVaEo2wdBSUCxGaiZ%252BJEIk4qYSQ4lyenj1zVr47XRq3b3Ao1npPIvmrqsqkvF9Vk8DG1OB%252FR3bOW8TWQqqx39mXishsItwoS8DZggh8iAGv0NHYg1%252BB3xgNjw%252B3Oe9CGEhm2Xa7Tf%252FLZCprLa6VtdgavUc08WJar5wa%252Bk97PZxfffjz4pDDPPskXrx%252F5K7f8rpEa%252FQbW0Ty9sqDCrFc8GPsdoO%252BV%252BF7f5GKCTF10kxUOToaQJvGQM1ZVuxdv15MvKN%252F%26RelayState%3Dhttps%253A%252F%252Faccounts.google.com%252FCheckCookie%253Fcontinue%253Dhttps%25253A%25252F%25252Fdocs.google.com%25252Fforms%25252Fd%25252Fe%25252F1FAIpQLScpV8Ay0-TT3BhuLoaY5UAugqsaIjtwzwxVMF6Cx9_d4aQT8g%25252Fviewform%25253Fvc%25253D0%252526c%25253D0%252526w%25253D1%2526hl%253Den-GB%2526checkedDomains%253Dyoutube%2526checkConnection%253Dyoutube%25253A783%25253A1%2526pstMsg%253D1");
		dr.get("https://globallogic.okta.com/login/login.htm?fromURI=%2Fapp%2Fgoogle%2Fexkco2xemQzomqLzc356%2Fsso%2Fsaml%3FSAMLRequest%3DfVLJTsMwEL0j8Q%252BR79kQILCaoAJCVGKJ2sCBm%252BtMUxfbEzxOC3%252BPm4KAAz1Zen5%252By3hGF%252B9GR2twpNAWLE8yFoGV2CjbFuypvonP2EV5eDAiYXTHx71f2im89UA%252BCi8t8eGiYL2zHAUp4lYYIO4ln43v7%252FhRkvHOoUeJmkWT64IZuVKvC%252Bx087oCMVdoRKtbOV9Z1S2lDYdZajSB%252Ffwd62gba0LUw8SSF9YHKMvP4zyP85M6O%252BV5xk%252BOX1hUfTldKrtrsC%252FWfEciflvXVVw9zupBYK0acA%252BBXbAWsdWQSDRb%252B0oQqXWAF0ITsGhMBM6HgFdoqTfgZuDWSsLT9K5gS%252B874mm62WySH5lUpK3GudAaWyV3iCRWDuPlQ0P3a67784tvf1bucxilv8TLr4%252Fc9ptcV6iV%252FIjGgby5ciB8KOddH7rdoDPC%252F%252B%252BfJ%252FmAqCZeDFTeW%252BpAqoWChkVpuXP9uzFhjz4B%26RelayState%3Dhttps%253A%252F%252Faccounts.google.com%252FCheckCookie%253Fcontinue%253Dhttps%25253A%25252F%25252Fdocs.google.com%25252Fforms%25252Fd%25252Fe%25252F1FAIpQLSd_CXQVxRsw6vervfVDE7Rk4d1EzAjr_TJbiSClhs2JrZhvzQ%25252Fviewform%25253Fvc%25253D0%252526c%25253D0%252526w%25253D1%2526hl%253Den-GB%2526checkedDomains%253Dyoutube%2526checkConnection%253Dyoutube%25253A212%25253A1%2526pstMsg%253D1");
		dr.findElement(By.xpath("//*[@id=\"okta-signin-username\"]")).sendKeys("vanapalli.tilak");
		dr.findElement(By.xpath("//*[@id=\"okta-signin-password\"]")).sendKeys("Abcde@0128");
		dr.findElement(By.xpath("//*[@id=\"okta-signin-submit\"]")).click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		dr.findElement(By.className("CwaK9")).click();
		Thread.sleep(5000);
		dr.findElement(By.xpath("/html/body/div[1]/div[2]/div[1]/div[2]/div[3]/a")).click();
		//Thread.sleep(3000);
		dr.findElement(By.xpath("//input[@name='emailAddress']")).clear();
		//Thread.sleep(2000);
		dr.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys("vanapalli.tilak@globallogic.com");
		dr.findElement(By.xpath("//input[@name='entry.1944997299']")).clear();
		//Thread.sleep(2000);
		dr.findElement(By.xpath("//input[@name='entry.1944997299']")).sendKeys("325137");
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[3]/div/div[2]/div/span/div/label[5]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[4]/div/div[2]/div/span/div/label[4]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[5]/div/div[2]/div/span/div/label[5]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[6]/div/div[2]/div/span/div/label[5]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[7]/div/div[2]/div/span/div/label[4]/div[2]")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[8]/div/div[2]/div/span/div/label[5]/div[2]")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[9]/div/div[2]/div/span/div/label[5]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[10]/div/div[2]/div/span/div/label[4]/div[2]/div/div[3]/div")).click();
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[2]/div[12]/div/div[2]/div/span/div/div[2]/label/div/div[1]/div[3]/div")).click();
	  
	    dr.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div/div[2]/div[3]/div[3]/div/div/span/span")).click();
	}
}
