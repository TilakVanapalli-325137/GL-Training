package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cart_page {
	  WebDriver dr;
	public cart_page(WebDriver d)
	{
		
		this.dr=d;
	}
	public String verify()
	{
		
		String s=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		System.out.println(s);
		return s;
	}

}
