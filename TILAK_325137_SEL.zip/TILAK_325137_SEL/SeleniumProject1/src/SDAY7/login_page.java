package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class login_page {
	static WebDriver dr;
	static By xname=By.xpath("//*[@id=\"user-name\"]");
	static By xpwd=By.xpath("//*[@id=\"password\"]");
	static By btn=By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]"); 
	public login_page(WebDriver dr)
	{
		this.dr=dr;
	}
	public static void enter_username(String uid)
	{
		dr.findElement(xname).sendKeys(uid);
	}

	public static void enter_password(String up)
	{
		dr.findElement(xpwd).sendKeys(up);
	}
	public static void click_btn()
	{
		dr.findElement(btn).click();
	}
	public  void login(String uid,String pwd)
	{
		this.enter_username(uid);
		this.enter_password(pwd);
		this.click_btn();
		
	}
	
	public String get_loginpage_title()
	{
		return dr.getTitle();
	}
	
}
