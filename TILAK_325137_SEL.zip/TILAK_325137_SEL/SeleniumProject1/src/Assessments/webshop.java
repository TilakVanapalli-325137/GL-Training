package Assessments;

public class webshop {

	public String keyword;
	public String xp;
	public String dt;
	public String ex_res;
	public String Tres;
	
}
