package Assessments;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class KWDFW {
	static webshop w;
	static webshop w1;
	WebDriver dr=new ChromeDriver();
	public static webshop read_excel(int i)
	{
	
		w=new webshop();
		try {
			File f=new File("C:\\Training\\BookAss.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new  XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(4);
			w.keyword=c.getStringCellValue();
			XSSFCell c1=r.getCell(5);
			w.xp=c1.getStringCellValue();
			XSSFCell c2=r.getCell(6);
			w.dt=c2.getStringCellValue();
			if((w.keyword).equals("verify"))
			{
			XSSFCell c3=r.getCell(7);
			w.ex_res=c3.getStringCellValue();
			}
			
		}
		
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(IOException ie)		
		{
			ie.printStackTrace();
		}
		return w;
	}
	
  @Test
  public void f() 
  {
	  String s;
	  System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		
	  for(int i=1;i<=16;i++)
	  {
		  w1=new webshop();
		  w1=read_excel(i);
		  s=w1.keyword;
		  switch(s)
		  {
		  case "launchchrome":launch(w1.dt);
		  						break;
		  case "closebrowser" :	closeb();
		  						break;
		  case "click_btn": click_btnn(w1.xp);
		  					break;
		  case "enter_txt":enter_txt(w1.xp,w1.dt);
		  					break;
		  case "verify": verify(w1.ex_res);
		  				break;
		  }
		  
	  }
	 
	  
  }

private void verify(String ex_res) {
	// TODO Auto-generated method stub
	String s1;
	s1=dr.findElement(By.xpath(ex_res)).getText();
		Assert.assertEquals(s1,ex_res);
}

private void enter_txt(String xp, String dt) {
	// TODO Auto-generated method stub
	dr.findElement(By.xpath(xp)).sendKeys(dt);
	
}

private void click_btnn(String x) {
	dr.findElement(By.xpath(x)).click();
	
}

private void closeb() {
	// TODO Auto-generated method stub
	dr.close();
}

private void launch(String dt) {
	// TODO Auto-generated method stub
	 System.out.println(dt);
		dr.get(dt);
	
}
}
