package Assessments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Register {
	WebDriver dr;
	@Test
	public void lg()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		  dr=new ChromeDriver();
		  dr.get("http://demowebshop.tricentis.com/register");
	}
  @Test(dataProvider = "Security")
  public void login(String uid,String xp,String dt ) {
	  
	  String s;
	  s=uid;
	  switch(s)
	  {
	  case "gender" : dr.findElement(By.xpath(xp)).click();
	  case "firstname": dr.findElement(By.xpath(xp)).sendKeys(dt);
	  					break;
	  case "lastname" :dr.findElement(By.xpath(xp)).sendKeys(dt);
	  					break;
	  case "email" :dr.findElement(By.xpath(xp)).sendKeys(dt);
	  				break;
	  case "password":dr.findElement(By.xpath(xp)).sendKeys(dt);
	  				break;
	  case "re-password" :dr.findElement(By.xpath(xp)).sendKeys(dt);
	  						break;
	  case "clickbutton" :dr.findElement(By.xpath(xp)).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  						String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
	  						String s2="Your registration completed";
	  						Assert.assertEquals(s1,s2);
	  						break;
	  				
	  						
	  						
	  }
	  
	  
	  
  }
  
  @DataProvider(name="Security")
  public String [][] getdata()
  {
	  String [][] data= {{"gender","//input[@id='gender-male']"," "},
			  {"firstname","//input[@id='FirstName']","Tilak"},
			  {"lastname","//input[@id='LastName']","tilak0128"},
			  {"email","//input[@id='Email']","abcdefghijklmno@gmail.com"},
			  {"password","//input[@id='Password']","tilak012890"},
			  {"re-password","//input[@id='ConfirmPassword']","tilak012890"},
			  {"clickbutton","//input[@id='register-button']",""}};
	  return data;
  }
}
