package SDAY4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class example {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.doxim.com/");
		dr.findElement(By.xpath("//*[@id=\"main\"]/section[1]/div/div/div/div[3]/div/div/p/a")).click();

	}

}
