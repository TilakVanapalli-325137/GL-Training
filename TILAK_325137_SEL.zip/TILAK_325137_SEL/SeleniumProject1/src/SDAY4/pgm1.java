package SDAY4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.naukri.com");
		String s=dr.getWindowHandle();
		for(String s1:dr.getWindowHandles())
		{
			dr.switchTo().window(s1);
			String title=dr.getTitle();
			System.out.println(title);
		}

	}

}
