package SDAY5;

import SDAY4.Tdata;
import SDAY4.pgm2;

import java.util.ArrayList;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class pgm3 {
	pgm2 p=new pgm2();
	ArrayList<Tdata> al_t;
	ArrayList<Tdata> al_t1;
	@BeforeClass
	public void t1()
	{
		al_t=new ArrayList<Tdata>();
		al_t1=p.readexcel();
	}
  @Test
  public void t2() {
	  p.login(al_t, 1);
  }
  
  @Test
  public void t3()
  {
	  p.login(al_t, 2);
  }
  @Test
  public void t4()
  {
	  p.login(al_t, 3);
  }
  
  @Test
  public void t5()
  {
	 al_t1=p.login(al_t, 4);
  }
  @Test
  public void t6()
  {
	p.writeexcel(al_t1);
  }
}
