package SDAY5;

import org.testng.annotations.Test;

public class pgm1 {
  @Test
  public void f() {
	  System.out.println("in test of f");
  }
  @Test
  public void f1()
  {
	  f();
  }
}
