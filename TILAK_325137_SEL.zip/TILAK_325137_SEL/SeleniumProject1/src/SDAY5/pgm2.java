package SDAY5;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class pgm2 {
	@BeforeTest
	public void BM()
	{
		System.out.println("BM");
	}
	@AfterTest
	public void AM()
	{
		System.out.println("AM");
	}
			public void c()
			{
				System.out.println("In test of c");
			}
  @Test
  public void b() 
  {
	  System.out.println("In test of b");
	  c();
  }
  @Test
  public void a() 
  {
	  System.out.println("In test of a");
	  c();
  }
  @Test
  public void d()
  {
	  System.out.println("In test of d");
	  c();
  }
  
}
