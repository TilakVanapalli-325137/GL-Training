package SDAY3;

public class user_details {
	public String uid,pass,eres,ares,tres;

}
