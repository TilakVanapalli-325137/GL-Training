package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {
	public static Ucredentials data;
	public static void main(String[] args) {
		data=read_excel();
		registration();
		write_excel(data);
	}
	public static Ucredentials read_excel() {
		Ucredentials u=new Ucredentials();
		try {
			File f=new File("C:\\Training\\BookUcredentials.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			u.fname=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			u.lname=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			u.mailid=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			u.pass=c3.getStringCellValue();
			XSSFCell c4=r.getCell(4);
			u.rpass=c4.getStringCellValue();
			XSSFCell c5=r.getCell(5);
			u.e_res=c5.getStringCellValue();
			System.out.println(u.fname+" "+u.lname+" "+u.mailid+" "+u.e_res);
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return u;
	}
	public static void registration() {
		   System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		   WebDriver dr=new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[1]/h1")).getText();
data.a_res=s;
String title=dr.getTitle();
System.out.println("title:"+title);
if(title.equals("Demo Web Shop. Register")) {
	System.out.println("title verified");
}
else {
	System.out.println("fail");
}
dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(data.fname);
dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(data.lname);
dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(data.mailid);
dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(data.pass);
dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(data.rpass);
dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
data.a_res=s1;
if(s1.equals(data.e_res)) {
	
	data.fresult="pass";
	String s2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	if(s2.equals(data.mailid))
	{
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
}
else {
	data.fresult="fail";
}

	}
	public static void write_excel(Ucredentials a) {

		
		try {
			File f=new File("C:\\Training\\BookUcredentials.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.createCell(6);
			c.setCellValue(a.e_res);
			XSSFCell c1=r.createCell(7);
			c1.setCellValue(a.fresult);
			
		     FileOutputStream fos=new FileOutputStream(f);
		     wb.write(fos);
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	/*{
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[1]/h1")).getText();
		if(s.equals("Register"))
		{
			System.out.println("Title Verified");
			java.util.List<WebElement> rb=dr.findElements(By.xpath("//*[@id=\"gender-male\"]"));
			((WebElement) rb.get(0)).click();
			dr.findElement(By.id("FirstName")).sendKeys("Tilak");
			dr.findElement(By.id("LastName")).sendKeys("Vanapalli");
			dr.findElement(By.id("Email")).sendKeys("tilaksthunder.111@gmail.com");
			dr.findElement(By.id("Password")).sendKeys("tilak0128");
			dr.findElement(By.id("ConfirmPassword")).sendKeys("tilak0128");
			dr.findElement(By.id("register-button")).click();
			String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();
			String s3=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[2]/div[1]/div/ul/li")).getText();
			System.out.println(s3);
			if(s1.equals("Your registration completed"))
			{
				
				String s2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
				if(s2.equals("tilaksthunder.111@gmail.com"))
				{
					System.out.println("Registraion Successfull");
					dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
					
					
				}
			}
			
			else if(s3.equals("The specified email already exists"))
			{
			
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			dr.findElement(By.id("Email")).sendKeys("tilaksthunder.111@gmail.com");
			dr.findElement(By.id("Password")).sendKeys("tilak0128");
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			}
		}
	}*/

}
