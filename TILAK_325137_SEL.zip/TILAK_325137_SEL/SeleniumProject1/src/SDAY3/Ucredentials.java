package SDAY3;

public class Ucredentials {

 
	public String fname;
	public String lname;
	public String mailid;
	public String pass;
	public String rpass;
	public String e_res;
	public String a_res;
	public String fresult;



}
