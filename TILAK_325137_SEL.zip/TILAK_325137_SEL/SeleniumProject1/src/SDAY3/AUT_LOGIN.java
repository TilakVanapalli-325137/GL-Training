package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AUT_LOGIN {
		 static  user_details testdata,test;
		public static user_details read_excel()
		{
			
			test=new user_details();
			try {
				File f=new File("C:\\Training\\SDAY3data.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(1);
				XSSFCell c=r.getCell(0);
				test.uid=c.getStringCellValue();
				XSSFCell c1=r.getCell(1);
				test.pass=c1.getStringCellValue();
				XSSFCell c2=r.getCell(2);
				test.eres=c2.getStringCellValue();
				
			}
			catch(FileNotFoundException ne)
			{
				ne.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			return test;
		}
		public static void write_excel(String s1,String s2)
		{
			test=new user_details();
			try {
				File f=new File("C:\\Training\\SDAY3data.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(1);
				XSSFCell c=r.createCell(3);
				test.ares=s2;
				c.setCellValue(test.ares);
				XSSFCell c1=r.createCell(4);
				test.tres=s1;
				c1.setCellValue(test.tres);
				System.out.println(test.tres);
				FileOutputStream fos=new FileOutputStream(f);
				wb.write(fos);
			}
			catch(FileNotFoundException ne)
			{
				ne.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	public static void login()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.name("Email")).sendKeys(testdata.uid);
		dr.findElement(By.name("Password")).sendKeys(testdata.pass);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		if(s.equals(testdata.eres))
		{
			String s1="pass";
			write_excel(s1,s);
		
		}
		else
		{
			String s2="fail";
			write_excel(s2,null);
	
		}
	}
	
	
	
	
	public static void main(String[] args) 
	{
		testdata=read_excel();
		login();
		

	}

}
