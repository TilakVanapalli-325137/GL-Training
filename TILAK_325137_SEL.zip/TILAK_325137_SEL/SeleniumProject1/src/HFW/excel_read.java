package HFW;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {
	public static String filename="C:\\Training\\HFWData.xlsx";
	public static String kw_sheet="KEYWORD";
	public static String tc_sheet="Sheet1";
	public static XSSFSheet kw_sh_obj,tc_sh_obj,td_sh_obj,s1,s2;
	public static ArrayList<login_test_data> td_al;


	    public static XSSFSheet set_sheet(String sheetname) {
	    XSSFSheet sh=null;
	   
	    try {
	File f=new File(filename);
	FileInputStream fis=new FileInputStream(f);
	XSSFWorkbook wb= new XSSFWorkbook(fis);
	sh=wb.getSheet(sheetname);

	}
	catch(FileNotFoundException e) {
	e.printStackTrace();
	}
	catch(IOException e) {
	e.printStackTrace();
	}
	return sh;
	}
	    public static tc_selection read_tc_selection(int i) {
	    tc_selection ts=new tc_selection();
	   
	    s1=set_sheet(tc_sheet);
	XSSFRow rw=s1.getRow(i);
	ts.tcid=rw.getCell(0).getStringCellValue();
	ts.flag=rw.getCell(1).getStringCellValue();
	ts.no_steps=(int)rw.getCell(2).getNumericCellValue();
	ts.test_data_sh=rw.getCell(3).getStringCellValue();
	
	    return ts;
	    }
	    public static keyword_sh read_keyword_sh(int i) {
	    keyword_sh kw=new keyword_sh();
	    s2=set_sheet(kw_sheet);
	    XSSFRow rw=s2.getRow(i);
	    kw.keyword=rw.getCell(3).getStringCellValue();
	kw.xpath=rw.getCell(4).getStringCellValue();
	kw.Test_Data=rw.getCell(5).getStringCellValue();
	System.out.println(kw.keyword);
	System.out.println(kw.xpath);
	System.out.println(kw.Test_Data);
	return kw;
	    }
	   
	   
	

}
