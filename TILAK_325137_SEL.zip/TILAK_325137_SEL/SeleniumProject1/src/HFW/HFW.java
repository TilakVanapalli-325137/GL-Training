package HFW;

public class HFW {

	static keyword_sh d=new keyword_sh();
	static tc_selection td=new tc_selection();
	static methods m=new methods();
	static excel_read ex=new excel_read();
	public static void main(String a[]) {
		String id,ch,testdata=null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
		td=ex.read_tc_selection(i);
		System.out.println(td.flag);
		if(td.flag.equals("y")) {
		for(j=1;j<16;j++) {
		d=excel_read.read_keyword_sh(j);
		System.out.println(d.keyword);
		ch=d.keyword;
		switch(ch) {
		case "launchchrome":

		m.launchchrome(d.Test_Data);
		}
		}
		}
		}

	}
}