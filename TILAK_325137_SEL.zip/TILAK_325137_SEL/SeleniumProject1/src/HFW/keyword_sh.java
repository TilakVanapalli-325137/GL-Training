package HFW;

public class keyword_sh {
	public String TC_ID;
	public String step_no;
	public String keyword;
	public String xpath;
	public String Test_Data;

}
