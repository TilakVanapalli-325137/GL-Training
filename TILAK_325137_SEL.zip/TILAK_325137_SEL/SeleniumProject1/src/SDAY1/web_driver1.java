package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class web_driver1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		dr.findElement(By.name("email")).sendKeys("tilaksthunder.111@gmail.com");
		dr.findElement(By.name("pass")).sendKeys("tilak@0128");
		dr.findElement(By.id("loginbutton")).click();
		
		
		
		
		
	}

}
