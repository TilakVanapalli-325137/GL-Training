package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class web_driver1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");

		
		WebElement we1=dr.findElement(By.id("day"));
		Select sel=new Select(we1);
		sel.selectByVisibleText("1");
		
		WebElement we2=dr.findElement(By.id("month"));
		Select sel1=new Select(we2);
		sel1.selectByVisibleText("Nov");
		
		WebElement we3=dr.findElement(By.id("year"));
		Select sel2=new Select(we3);
		sel2.selectByVisibleText("1997");
		/////////////////
		String title=dr.getTitle();
		System.out.println("Title :"+title);
		
		java.util.List<WebElement> rb=dr.findElements(By.name("sex"));
		((WebElement) rb.get(0)).click();
		System.out.println((WebElement) rb.get(0));
		
		
		
		/*dr.findElement(By.name("websubmit")).click();*/
		/*String profileName=dr.findElement(By.id("span")).getText();
		String expectedProfileName="Tilak";
		
		if(profileName.compareTo(expectedProfileName)==0)
		{
			System.out.println("login successful");
		}
		
		else
		{
			System.out.println("login Failed");
		}
		
		*/
		
		
		
	}

}
