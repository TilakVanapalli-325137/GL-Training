$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("b.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@ROUND1"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "User enters login details",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test.login_page_is_displayed()"
});
formatter.result({
  "duration": 9518606900,
  "status": "passed"
});
formatter.match({
  "location": "test.user_enters_login_details()"
});
formatter.result({
  "duration": 1960718500,
  "status": "passed"
});
formatter.match({
  "location": "test.home_page_is_displayed()"
});
formatter.result({
  "duration": 51829200,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [tilakthunder.111@gmail.com] but found [tilaksthunder.111@gmail.com]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test.home_page_is_displayed(test.java:40)\r\n\tat ✽.Then home page is displayed(b.feature:8)\r\n",
  "status": "failed"
});
});