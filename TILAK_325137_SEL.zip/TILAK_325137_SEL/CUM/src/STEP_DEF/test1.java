package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	
		@When("^User enters invalid login details$")
		public void user_enters_invalid_login_details() throws Throwable {
			dr=test.dr;
			System.out.println("User entered invalid login details");
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
			dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("tilaktillu@gmail.com");
			dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("6r2376376");
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		}
		@Then("^Home page is not displayed$")
		public void home_page_is_not_displayed() throws Throwable {
			System.out.println("Home Page is not displayed");
		}
	
}
