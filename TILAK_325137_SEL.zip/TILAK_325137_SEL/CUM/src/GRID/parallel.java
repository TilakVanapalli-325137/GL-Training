package GRID;

import org.testng.annotations.Test;

public class parallel {

	@Test
	public void t1() {
		System.out.println("in a t1- start");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		System.out.println("in a t1-stops");
	}
	@Test
	public void t2()
	{
		System.out.println("in a t2-start");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("in t2-stops");
	}
}
