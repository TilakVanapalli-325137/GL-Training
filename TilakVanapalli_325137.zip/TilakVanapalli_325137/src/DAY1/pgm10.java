package DAY1;
import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		
		char  c;
		System.out.println("enter any character");
	   Scanner sc=new Scanner(System.in);
	   c=sc.next().charAt(0);
		if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			System.out.println("it is vowel");
		else
		{
			System.out.println("it is not vowel");
		}
	}

}
