package DAY4;

public class Student {
	int rollno;
	String name;
	int m1;
	int m2;
	float avg;
	public Student(int rollno,String name,int m1,int m2)
	{
		this.rollno=rollno;
		this.name=name;
		this.m1=m1;
		this.m2=m2;
		
	}
	public void display()
	{
		System.out.println("Rollno "+rollno);
		System.out.println("name "+name);
		System.out.println("M1 marks "+m1);
		System.out.println("M2 marks "+m2);
	}
	public static void main(String[] args) {
		Student s1=new Student(501,"tilak",98,95);
		Student s2=new Student(502,"vanapalli",90,85);
	 s1.display();
	 s2.display();
	}

}
