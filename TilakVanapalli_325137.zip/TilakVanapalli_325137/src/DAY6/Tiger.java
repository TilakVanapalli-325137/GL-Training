package DAY6;

public class Tiger extends Animal{
	int lott;
	int loc;
	int legs;
	int age;
	String gender;
	String disabilities;
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void mauls() {
		System.out.println("Tiger mauls its prey");
	}
	
		
		
	public Tiger(int lott, int loc,int legs,int age,String gender,String disabilities) {
		this.lott=lott;
		this.loc=loc;
		this.legs=legs;
		this.age=age;
		this.gender=gender;
		this.disabilities=disabilities;
	}


	public void display() {
		System.out.println(" No of legs: " +this.legs + " Skin color: "+ this.color + " Food: " + this.food + " Name: "+this.name 
							+ " Gender: " + this.gender + " Age: " + this.age+"Disabilities :"+this.disabilities );
		
		System.out.println(" Length of teeth : "+ this.lott + " Length of claws : " + this.loc);
	}

}
