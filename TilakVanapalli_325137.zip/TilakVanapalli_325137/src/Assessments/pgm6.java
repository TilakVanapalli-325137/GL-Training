package Assessments;

import java.util.ArrayList;


public class pgm6 {

	public static void main(String[] args) {
		ArrayList<product> al = new ArrayList<product>();
		excel_op op1 = new excel_op();
		
		al=op1.read_excel();
		
		op1.write_excel(al);

	}

}
