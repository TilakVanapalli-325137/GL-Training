package Assessments;

import java.util.ArrayList;

public class pgm3 {



	public static void main(String[] args) {
		int i;
		ArrayList<Integer> i_al=new ArrayList<Integer>();
		for(i=10;i<=30;i++)
		{
			if(i%2==0)
			{
				i_al.add(i);
			}
		}
		System.out.println(i_al);
	}

}
