package Assessments;

import java.util.ArrayList;

public class vowel {

	public static void main(String[] args) {
		
		String line="I have learnt loops,oops concepts,inheritance,exception handling, arraylist and string handling";
		get_each_word(line);
	}
		public static  ArrayList<String> get_each_word(String str)
		{
			ArrayList<String> st_al=new ArrayList<String>();
			String s;
			int p;
			p=0;
			int l=str.length();
			for(int i=0;i<l;i++)
			{
			
				if(str.charAt(i)==' '&&str.charAt(i+1)!=' '||str.charAt(i)==',')
				{
					s=str.substring(p,i);
					p=i+1;
					st_al.add(s);
					
				}
			}
			System.out.println(st_al);
			count_vowels(st_al);
			return null;
		}

	public static ArrayList<String> count_vowels(ArrayList<String> st_al)
	{
		int l;
		for(String s:st_al)
		{
			int count=0;
			l=s.length();
			for(int i=0;i<l;i++)
			{
				if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')
				{
					count++;	
				}
				
			}
			if(count>=3)
			{
				System.out.println(s);
			}
		}
		
		
		return null;
	}

}
