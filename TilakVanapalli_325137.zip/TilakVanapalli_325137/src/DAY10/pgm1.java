package DAY10;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		excel_op ex=new excel_op();
		ex.readt3();
		ex.readt2();
		ex.readt1();
		ex.write();
	}

}
