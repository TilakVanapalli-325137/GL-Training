package DAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_op {
	ArrayList<Table3> t3_al;
	ArrayList<Table2> t2_al;
	ArrayList<Table1> t1_al;
	public void readt3() 
	{
		t3_al=new ArrayList<Table3>();
		
		try {
			File f=new File("C:\\Training\\Table3.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			int fr=sh.getFirstRowNum();
			int lr=sh.getLastRowNum();
			int nor=lr-fr+1;
			for(int i=fr+1;i<=nor-1;i++)
			{
				Table3 t3=new Table3();
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.getCell(0);
				t3.customer_id=(int) c.getNumericCellValue();
				
				XSSFCell c1=r.getCell(1);
				t3.route_id=(int) c1.getNumericCellValue();
				
				XSSFCell c2=r.getCell(2);
				t3.not=(int) c2.getNumericCellValue();
				
			t3_al.add(t3);	
				
			}
			}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}
		
	}
	
	public void readt2()
	{
		int row=1;
		t2_al=new ArrayList<Table2>();
		try {
			File f=new File("C:\\Training\\Table2.xlsx");
			FileInputStream fis1=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis1);
			XSSFSheet sh=wb.getSheet("Sheet1");	
			int fr1=sh.getFirstRowNum();
			int lr1=sh.getLastRowNum();
			int nor1=lr1-fr1+1;
			for(int i1=fr1+1;i1<=nor1-1;i1++)
			{
				Table2 t2=new Table2();
				XSSFRow r=sh.getRow(i1);
				XSSFCell c=r.getCell(0);
				t2.customer_id=(int) c.getNumericCellValue();
				
				XSSFCell c1=r.getCell(1);
				t2.customer_name=c1.getStringCellValue();
			t2_al.add(t2);	
				
			}	
			}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}
	}
	public void readt1()
	{
		int row=1;
		t1_al=new ArrayList<Table1>();
		try {
			File f=new File("C:\\Training\\Table1.xlsx");
			FileInputStream fis2=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis2);
			XSSFSheet sh=wb.getSheet("Sheet1");	
			int fr1=sh.getFirstRowNum();
			int lr1=sh.getLastRowNum();
			int nor1=lr1-fr1+1;
			for(int i1=fr1+1;i1<=nor1-1;i1++)
			{
				Table1 t1=new Table1();
				XSSFRow r=sh.getRow(i1);
				XSSFCell c=r.getCell(0);
				t1.route_id=(int) c.getNumericCellValue();
				
				XSSFCell c1=r.getCell(1);
				t1.from=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				t1.to=c2.getStringCellValue();
				XSSFCell c3=r.getCell(3);
				t1.unit_price=(int) c3.getNumericCellValue();
				
			t1_al.add(t1);	
				
			}	
			}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}
	}
	 public void write() 
	 {
		 Table4 t4=new Table4();
		 Table3 tt3=new Table3();
		try { 
			File f=new File("C:\\Training\\Table4.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int i=0;i<=1;i++)
			{
			tt3=t3_al.get(i);
			t4.customer_id=tt3.customer_id;
			for(Table2 t2: t2_al)
			{
				if(tt3.customer_id==t2.customer_id)
				{
					t4.customer_name=t2.customer_name;
					XSSFRow r=sh.createRow(i);
					XSSFRow r1=sh.getRow(i);
					XSSFCell c=r1.createCell(0);
					c.setCellValue(t4.customer_id);
					XSSFCell c1=r1.createCell(1);
					c1.setCellValue(t4.customer_name);
					break;
				}
				
			}
			}
			XSSFRow r=sh.createRow(2);
			for(int i=0;i<=1;i++)
			{
			tt3=t3_al.get(i);
			for(Table1 t1: t1_al)
			{
				if(tt3.route_id==t1.route_id)
				{
					t4.from=t1.from;
					t4.to=t1.to;
					t4.unit_price=t1.unit_price;
					XSSFRow r1=sh.getRow(i);
					XSSFCell c=r1.createCell(2);
					XSSFCell c1=r1.createCell(3);
					XSSFCell c2=r1.createCell(4);
					c.setCellValue(t4.from);
					c1.setCellValue(t4.to);
					c2.setCellValue(t4.unit_price);
					break;
				}
				
			}
			}
			for(int i=0;i<=1;i++)
			{
			tt3=t3_al.get(i);
			t4.not=tt3.not;
			XSSFRow r1=sh.getRow(i);
			XSSFCell c=r1.createCell(5);
			c.setCellValue(t4.not);
			}
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException ie)
		{
			ie.printStackTrace();
		}
		 
		 
	 }
	
}
