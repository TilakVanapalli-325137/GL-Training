package DAY10;

public class Table4 {
public int customer_id;
public String customer_name;
public String from;
public String to;
public int unit_price;
public int not;
public int total_price;

	public void total_price()
	{
		this.total_price=this.unit_price*this.not;
	}



}
