package DAY10;

public class Table1 {

	public int route_id;
	public String  from;
	public String to;
	public int unit_price;
}
