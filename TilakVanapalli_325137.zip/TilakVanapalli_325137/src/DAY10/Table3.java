package DAY10;

public class Table3 {
public int customer_id;
public int route_id;
public int not;

}
