package DAY10;

public class Table2 {
	public int customer_id;
	public String customer_name;

}
